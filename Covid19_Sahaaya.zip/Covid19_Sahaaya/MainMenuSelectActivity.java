package studio.knowhere.Covid19_Sahaaya.Activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import studio.knowhere.Covid19_Sahaaya.Class.PreferenceManager;
import studio.knowhere.Covid19_Sahaaya.R;
import studio.knowhere.Covid19_Sahaaya.SplashActivity;

public class MainMenuSelectActivity extends AppCompatActivity {


    Button info_btn, fclinic_btn, test_centres_btn, hospitals_btn, signup_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu_select);


	info_btn = (Button) findViewById(R.id.info_btn);//get id of button 1
        fclinic_btn = (Button) findViewById(R.id.fclinic_btn);//get id of button 2
        test_centres_btn = (Button) findViewById(R.id.test_centres_btn);//get id of button 1
        hospitals_btn = (Button) findViewById(R.id.hospitals_btn);//get id of button 2
        signup_btn = (Button) findViewById(R.id.signup_btn);//get id of button 1



        info_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Toast.makeText(getApplicationContext(), "Info button pressed", Toast.LENGTH_LONG).show();//display the text of button1
                Intent j = new Intent(MainMenuSelectActivity.this, InfoActivity.class);

                startActivity(j);

            }
        });
        fclinic_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // Toast.makeText(getApplicationContext(), "Search clinic button pressed", Toast.LENGTH_LONG).show();//display the text of button2
                Intent j = new Intent(MainMenuSelectActivity.this, FclinicActivity.class);

               startActivity(j);
            }
        });
        test_centres_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Test centres button pressed", Toast.LENGTH_LONG).show();//display the text of button1
            }
        });
        hospitals_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Hospitals button pressed", Toast.LENGTH_LONG).show();//display the text of button2
            }
        });

        signup_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Toast.makeText(getApplicationContext(), "Hospitals button pressed", Toast.LENGTH_LONG).show();//display the text of button2
                // Start your app main activity
                Intent i = new Intent(MainMenuSelectActivity.this, LoginActivity.class);

                startActivity(i);
            }
        });

    }
}
