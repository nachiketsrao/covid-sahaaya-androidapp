package studio.knowhere.Covid19_Sahaaya.Activity;

public class APIs {

    public String LOGINAPI = "http://18.216.147.252:3002/user/login";
    public String REGISTERAPI = "http://18.216.147.252:3002/user";
    public String USERLIST = "http://18.216.147.252:3002/user";
    public String ADDDONAR = "http://18.216.147.252:3002/donor";
    public String PROFILE = "http://18.216.147.252:3002/user?user_id=";
    public String DonarComm = "http://18.216.147.252:3002/donor/byuser/";
    public String AvailabilityStatus = "http://18.216.147.252:3002/user/availablity/";
    public String PlasmaAvailabilityStatus = "http://18.216.147.252:3002/user/plasma/";



    public String getLOGINAPI() {
        return LOGINAPI;
    }

    public void setLOGINAPI(String LOGINAPI) {
        this.LOGINAPI = LOGINAPI;
    }

    public String getREGISTERAPI() {
        return REGISTERAPI;
    }

    public void setREGISTERAPI(String REGISTERAPI) {
        this.REGISTERAPI = REGISTERAPI;
    }

    public String getUSERLIST() {
        return USERLIST;
    }

    public void setUSERLIST(String USERLIST) {
        this.USERLIST = USERLIST;
    }

    public String getADDDONAR() {
        return ADDDONAR;
    }

    public void setADDDONAR(String ADDDONAR) {
        this.ADDDONAR = ADDDONAR;
    }

    public String getPROFILE() {
        return PROFILE;
    }

    public void setPROFILE(String PROFILE) {
        this.PROFILE = PROFILE;
    }

    public String getDonarComm() {
        return DonarComm;
    }

    public void setDonarComm(String donarComm) {
        DonarComm = donarComm;
    }

    public String getAvailabilityStatus() {
        return AvailabilityStatus;
    }

    public void setAvailabilityStatus(String availabilityStatus) {
        AvailabilityStatus = availabilityStatus;
    }

    public String getPlasmaAvailabilityStatus() {
        return PlasmaAvailabilityStatus;
    }

    public void setPlasmaAvailabilityStatus(String plasmaAvailabilityStatus) {
        PlasmaAvailabilityStatus = plasmaAvailabilityStatus;
    }
}
