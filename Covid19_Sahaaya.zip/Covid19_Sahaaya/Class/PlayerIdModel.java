package studio.knowhere.Covid19_Sahaaya.Class;

public class PlayerIdModel {

    public String playrid;

    public String getPlayrid() {
        return playrid;
    }

    public void setPlayrid(String playrid) {
        this.playrid = playrid;
    }
}
