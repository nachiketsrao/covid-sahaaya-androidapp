package studio.knowhere.Covid19_Sahaaya.Class;

public class User {
}
