package studio.knowhere.Covid19_Sahaaya.Class;

public class SignupClass {



    private  static String deviceid;


    public static String getDeviceid() {
        return deviceid;
    }

    public static void setDeviceid(String deviceid) {
        SignupClass.deviceid = deviceid;
    }



}
